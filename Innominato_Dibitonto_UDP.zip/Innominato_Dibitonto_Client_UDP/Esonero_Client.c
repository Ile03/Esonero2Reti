/*
 #########################################
 Name        : Esonero_Client.c (UDP)
 Authors     : Ileana Pia Innominato, Michela Dibitonto
 #########################################
*/

#if defined WIN32
#include <winsock2.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Protocol.h"

// Prototypes
void clearwinsock();
void errorhandler(char *errorMessage);
void display_help_menu();

int main(void) {
    #if defined WIN32
    // Initialize Winsock
    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (result != 0) {
        printf("Error at WSAStartup()\n");
        return 0;
    }
    #endif

    // Create client UDP socket
    int client_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (client_socket < 0) {
        errorhandler("Socket creation failed.\n");
        clearwinsock();
        return -1;
    }

    // Set server address
    struct sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = inet_addr(PROTO_ADDR);
    server_address.sin_port = htons(PROTO_PORT);

    char buffer[BUFFER_SIZE];

    printf("Welcome to the Password Generator Client!\n");
    while (1) {
        printf("Enter command (h for help, q to quit): ");
        fgets(buffer, BUFFER_SIZE, stdin);
        buffer[strcspn(buffer, "\n")] = '\0'; // Remove newline

        // Handle 'q' command
        if (strcmp(buffer, "q") == 0) {
            printf("Exiting application. Goodbye!\n");
            closesocket(client_socket);
            clearwinsock();
            return 0;
        }

        // Handle 'h' command
        if (strcmp(buffer, "h") == 0) {
            display_help_menu();
            continue;
        }

        // Send command to server
        int bytes_sent = sendto(client_socket, buffer, strlen(buffer), 0,
                                (struct sockaddr*)&server_address, sizeof(server_address));
        if (bytes_sent < 0) {
            errorhandler("Failed to send message to server.\n");
            continue;
        }

        // Receive response from server
        struct sockaddr_in from_address;
        socklen_t from_length = sizeof(from_address);
        int bytes_received = recvfrom(client_socket, buffer, BUFFER_SIZE - 1, 0,
                                      (struct sockaddr*)&from_address, &from_length);
        if (bytes_received < 0) {
            errorhandler("Failed to receive response from server.\n");
            continue;
        }

        buffer[bytes_received] = '\0'; // Null-terminate response
        printf("Server response: %s\n", buffer);
    }

    // Clean up
    closesocket(client_socket);
    clearwinsock();
    return 0;
}

void display_help_menu() {
    printf("\nPassword Generator Help Menu\n");
    printf("Commands:\n");
    printf("  h        : show this help menu\n");
    printf("  n LENGTH : generate numeric password (digits only)\n");
    printf("  a LENGTH : generate alphabetic password (lowercase letters)\n");
    printf("  m LENGTH : generate mixed password (lowercase letters and numbers)\n");
    printf("  s LENGTH : generate secure password (uppercase, lowercase, numbers, symbols)\n");
    printf("  u LENGTH : generate unambiguous secure password (no similar-looking characters)\n");
    printf("  q        : quit application\n\n\n\n");
    printf("LENGTH must be between 6 and 32 characters\n\n");
    printf("Ambiguous characters excluded in 'u' option:\n");
    printf("  0 O o (zero and letters O)\n");
    printf("  1 l I i (one and letters l, I)\n");
    printf("  2 Z z (two and letter Z)\n");
    printf("  5 S s (five and letter S)\n");
    printf("  8 B (eight and letter B)\n");
}

void clearwinsock() {
    #if defined WIN32
    WSACleanup();
    #endif
}

void errorhandler(char *errorMessage) {
    fprintf(stderr, "%s\n", errorMessage);
}
