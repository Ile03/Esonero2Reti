/*
 #########################################
 Name        : Protocol.h (Client)
 Authors     : Ileana Pia Innominato, Michela Dibitonto
 #########################################
*/

#ifndef PROTOCOL_H
#define PROTOCOL_H

// Server address and port
#define PROTO_ADDR "127.0.0.1" // Replace with actual server address if DNS is used
#define PROTO_PORT 54321

// Password constraints
#define MIN_PASSWORD_LENGTH 6
#define MAX_PASSWORD_LENGTH 32

// Buffer size for client-server communication
#define BUFFER_SIZE 256

// Define socklen_t for compatibility on Windows
#if defined WIN32
    typedef int socklen_t;
#endif

#endif // PROTOCOL_H
