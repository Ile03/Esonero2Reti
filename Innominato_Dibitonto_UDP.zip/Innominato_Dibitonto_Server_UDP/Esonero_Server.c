/*
 #########################################
 Name        : Esonero_Server.c (UDP)
 Authors     : Ileana Pia Innominato, Michela Dibitonto
 #########################################
*/

#if defined WIN32
#include <winsock2.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Protocol.h"
#include "PasswordGenerator.h"

// Function prototypes
void clearwinsock();
void errorhandler(char *errorMessage);

int main(void) {
    #if defined WIN32
    // Initialize Winsock
    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (result != 0) {
        printf("Error at WSAStartup()\n");
        return 0;
    }
    #endif

    // Create server UDP socket
    int server_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (server_socket < 0) {
        errorhandler("Socket creation failed.\n");
        clearwinsock();
        return -1;
    }

    // Set server address and port
    struct sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address)); // Clear structure
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = htonl(INADDR_ANY);
    server_address.sin_port = htons(PROTO_PORT);

    // Bind socket to address
    if (bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address)) < 0) {
        errorhandler("bind() failed.\n");
        closesocket(server_socket);
        clearwinsock();
        return -1;
    }

    printf("Server is running on port %d...\n", PROTO_PORT);

    while (1) {
        char buffer[BUFFER_SIZE];
        struct sockaddr_in client_address;
        socklen_t client_len = sizeof(client_address);

        // Receive datagram from client
        int bytes_received = recvfrom(server_socket, buffer, BUFFER_SIZE - 1, 0,
                                      (struct sockaddr*)&client_address, &client_len);
        if (bytes_received < 0) {
            errorhandler("recvfrom() failed.\n");
            continue;
        }

        buffer[bytes_received] = '\0'; // Null-terminate received data

        // Log client info
        printf("New request from %s:%d\n", inet_ntoa(client_address.sin_addr), ntohs(client_address.sin_port));

        // Parse client request
        char type;
        int length;
        if (sscanf(buffer, "%c %d", &type, &length) != 2 || length < MIN_PASSWORD_LENGTH || length > MAX_PASSWORD_LENGTH) {
            snprintf(buffer, BUFFER_SIZE, "Invalid request. Use format '<type> <length>'.\n");
        } else {
            char *password = NULL;
            switch (type) {
                case 'n':
                    password = generate_numeric(length);
                    break;
                case 'a':
                    password = generate_alpha(length);
                    break;
                case 'm':
                    password = generate_mixed(length);
                    break;
                case 's':
                    password = generate_secure(length);
                    break;
                case 'u':
                    password = generate_unambiguous(length);
                    break;
                default:
                    snprintf(buffer, BUFFER_SIZE, "Invalid password type. Use 'n', 'a', 'm', 's', or 'u'.\n");
            }

            if (password) {
                strncpy(buffer, password, BUFFER_SIZE - 1);
                buffer[BUFFER_SIZE - 1] = '\0';
                free(password);
            }
        }

        // Send response to client
        sendto(server_socket, buffer, strlen(buffer), 0,
               (struct sockaddr*)&client_address, client_len);
    }

    // Clean up
    closesocket(server_socket);
    clearwinsock();
    return 0;
}

void clearwinsock() {
    #if defined WIN32
    WSACleanup();
    #endif
}

void errorhandler(char *errorMessage) {
    fprintf(stderr, "%s\n", errorMessage);
}
