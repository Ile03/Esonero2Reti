/*
 #########################################
 Name        : PasswordGenerator.c
 Authors     : Ileana Pia Innominato, Michela Dibitonto
 #########################################
*/

#include "PasswordGenerator.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MIN_PASSWORD_LENGTH 6
#define MAX_PASSWORD_LENGTH 32

char *generate_numeric(int length) {
    char *password = malloc(length + 1);
    if (!password) return NULL;
    for (int i = 0; i < length; i++) {
        password[i] = '0' + rand() % 10;
    }
    password[length] = '\0';
    return password;
}

char *generate_alpha(int length) {
    char *password = malloc(length + 1);
    if (!password) return NULL;
    for (int i = 0; i < length; i++) {
        password[i] = 'a' + rand() % 26;
    }
    password[length] = '\0';
    return password;
}

char *generate_mixed(int length) {
    char *password = malloc(length + 1);
    if (!password) return NULL;
    for (int i = 0; i < length; i++) {
        if (rand() % 2 == 0)
            password[i] = 'a' + rand() % 26;
        else
            password[i] = '0' + rand() % 10;
    }
    password[length] = '\0';
    return password;
}

char *generate_secure(int length) {
    char *password = malloc(length + 1);
    if (!password) return NULL;

    const char symbols[] = "!@#$%^&*()_+";
    for (int i = 0; i < length; i++) {
        int type = rand() % 4;
        if (type == 0)
            password[i] = 'a' + rand() % 26;
        else if (type == 1)
            password[i] = 'A' + rand() % 26;
        else if (type == 2)
            password[i] = '0' + rand() % 10;
        else
            password[i] = symbols[rand() % (sizeof(symbols) - 1)];
    }
    password[length] = '\0';
    return password;
}

char *generate_unambiguous(int length) {
    char *password = malloc(length + 1);
    if (!password) return NULL;

    const char unambiguous[] = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz234679";
    size_t unambiguous_size = strlen(unambiguous);

    for (int i = 0; i < length; i++) {
        password[i] = unambiguous[rand() % unambiguous_size];
    }
    password[length] = '\0';
    return password;
}
